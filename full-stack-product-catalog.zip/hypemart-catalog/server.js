const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const products = [
  {id:1,name:'Cloud Knit Hoodie',category:'Clothing',price:1299,rating:4.8,emoji:'🧥',color:'lavender',description:'Soft everyday comfort with a relaxed fit.'},
  {id:2,name:'Studio Wireless Headphones',category:'Tech',price:2499,rating:4.7,emoji:'🎧',color:'blue',description:'Immersive sound for work, study and play.'},
  {id:3,name:'Everyday Carry Bottle',category:'Lifestyle',price:599,rating:4.5,emoji:'🧴',color:'mint',description:'A reusable bottle built for busy days.'},
  {id:4,name:'Minimal Desk Lamp',category:'Home',price:1599,rating:4.6,emoji:'💡',color:'peach',description:'Warm light for late-night ideas.'},
  {id:5,name:'Retro Runner Sneakers',category:'Clothing',price:2199,rating:4.9,emoji:'👟',color:'peach',description:'A lightweight sneaker with a vintage look.'},
  {id:6,name:'Pocket Bluetooth Speaker',category:'Tech',price:1799,rating:4.4,emoji:'🔊',color:'lavender',description:'Big sound in a small travel-friendly body.'},
  {id:7,name:'Ceramic Coffee Set',category:'Home',price:899,rating:4.6,emoji:'☕',color:'mint',description:'A calm little ritual for your morning.'},
  {id:8,name:'Canvas Day Tote',category:'Lifestyle',price:749,rating:4.3,emoji:'👜',color:'blue',description:'Roomy, simple and ready for every day.'}
];

app.get('/api/health', (req,res) => res.json({status:'ok',message:'HypeMart API is running'}));
app.get('/api/products', (req,res) => {
  const q=(req.query.q || '').toLowerCase().trim();
  const category=(req.query.category || 'All').toLowerCase();
  const sort=req.query.sort || 'featured';
  let result=products.filter(p=>(!q || `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q)) && (category==='all' || p.category.toLowerCase()===category));
  if(sort==='price-low') result.sort((a,b)=>a.price-b.price);
  if(sort==='price-high') result.sort((a,b)=>b.price-a.price);
  if(sort==='rating') result.sort((a,b)=>b.rating-a.rating);
  res.json({count:result.length,products:result});
});
app.get('/api/products/:id', (req,res) => {
  const product=products.find(p=>p.id===Number(req.params.id));
  if(!product) return res.status(404).json({error:'Product not found'});
  res.json(product);
});
app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT, () => console.log(`HypeMart is running at http://localhost:${PORT}`));
