const productGrid=document.querySelector('#products');
const searchInput=document.querySelector('#search');
const sortSelect=document.querySelector('#sort');
const categoryButtons=[...document.querySelectorAll('[data-category]')];
const resultCount=document.querySelector('#resultCount');
const message=document.querySelector('#message');
const cartCount=document.querySelector('#cartCount');
const toast=document.querySelector('#toast');
let category='All',cart=0,toastTimer;
const money=value=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(value);
function showToast(text){toast.textContent=text;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2200);}
async function loadProducts(){
  message.textContent='';
  const params=new URLSearchParams({q:searchInput.value.trim(),category,sort:sortSelect.value});
  try{
    const response=await fetch(`/api/products?${params}`);
    if(!response.ok)throw new Error('The product service returned an error.');
    const data=await response.json();
    resultCount.textContent=`${data.count} ${data.count===1?'item':'items'}`;
    if(!data.products.length){productGrid.innerHTML='<div class="empty">No products found. Try another search or category ✨</div>';return;}
    productGrid.innerHTML=data.products.map(p=>`<article class="product"><div class="product-art ${p.color}"><span class="tag">${p.category}</span>${p.emoji}</div><div class="product-info"><div class="product-meta"><span>★ ${p.rating.toFixed(1)} rating</span><span>Curated pick</span></div><h3>${escapeHTML(p.name)}</h3><p>${escapeHTML(p.description)}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add" data-add="${p.id}" aria-label="Add ${escapeHTML(p.name)} to bag">+</button></div></div></article>`).join('');
  }catch(error){productGrid.innerHTML='<div class="empty">Could not load products. Make sure the server is running, then refresh.</div>';message.textContent=error.message;}
}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
searchInput.addEventListener('input',loadProducts);
sortSelect.addEventListener('change',loadProducts);
categoryButtons.forEach(button=>button.addEventListener('click',()=>{category=button.dataset.category;categoryButtons.forEach(b=>b.classList.toggle('active',b===button));loadProducts();}));
productGrid.addEventListener('click',event=>{const button=event.target.closest('[data-add]');if(!button)return;cart++;cartCount.textContent=cart;showToast('Added to your bag — nice choice! ✨');});
document.querySelector('#cartButton').addEventListener('click',()=>showToast(cart?`Your bag has ${cart} ${cart===1?'item':'items'} (demo only).`:'Your bag is empty. Add something you love!'));
loadProducts();
