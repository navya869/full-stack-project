# HypeMart — Full-Stack Product Catalog

**Created by:** Navya  
**Email:** kuninavya09@gmail.com

A responsive product catalog with a Node.js + Express backend and a frontend that fetches product data through REST endpoints. It demonstrates modular frontend structure, search, category filters, sorting, responsive design, client-side interactions and API routing.

## Requirements
- Node.js 18 or newer
- Internet access is optional for app functionality; it is used only for Google Fonts.

## Run locally
1. Install Node.js from https://nodejs.org/ if it is not installed.
2. Extract the ZIP and open the `hypemart-catalog` folder in VS Code.
3. Open a terminal in that folder and run:

   ```bash
   npm install
   npm start
   ```

4. Open `http://localhost:3000` in your browser.
5. Test the API directly at `http://localhost:3000/api/products` and `http://localhost:3000/api/health`.

## Features
- Product catalog served from an Express REST API
- Search across product name, category and description
- Category filters: Tech, Clothing, Home and Lifestyle
- Sorting by featured, price and rating
- Add-to-bag interaction with a live item count (demo only)
- Responsive layout for desktop and mobile
- API health endpoint and product-by-ID endpoint

## API endpoints
- `GET /api/health` — health status
- `GET /api/products` — all products
- `GET /api/products?q=headphones` — search
- `GET /api/products?category=Tech` — filter by category
- `GET /api/products?sort=price-low` — sort by price
- `GET /api/products/1` — fetch one product

## Deploy
You can deploy the app to a Node-compatible hosting platform such as Render:
1. Create a GitHub repository and upload the contents of this project folder.
2. Create a new Web Service on Render and connect that repository.
3. Set **Build Command** to `npm install` and **Start Command** to `npm start`.
4. Deploy and open the public URL provided by the hosting platform.

Free hosting availability and limits can change. The project does not require a paid API. Do not add secrets or passwords to this repository.

## Project structure
- `server.js` — Express backend and REST API
- `public/index.html` — page structure
- `public/style.css` — styling and responsive layout
- `public/app.js` — API requests, filters, sorting and interactions
- `package.json` — project metadata and dependencies

## Before submitting
- [ ] Run `npm install` and `npm start`
- [ ] Verify the product list loads
- [ ] Test search, category filters and sorting
- [ ] Test adding an item to the bag
- [ ] Capture screenshots of the working app
- [ ] If a public URL is required, deploy it and include that URL in your submission

**Note:** This is a demonstration catalog. Products, ratings and prices are sample data; the bag does not process payments or place real orders.
